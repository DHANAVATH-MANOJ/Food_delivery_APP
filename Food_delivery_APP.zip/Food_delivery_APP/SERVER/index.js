const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const db = require('./firebaseConfig');

const app = express();
const PORT = 5000;

app.use(cors());
app.use(bodyParser.json());
app.use(express.static('public'));

let statusSteps = [
  "Order Placed",
  "Preparing",
  "Picked by Delivery Partner",
  "On the Way",
  "Delivered"
];

// Save order to Firebase
app.post('/place-order', async (req, res) => {
  const order = req.body;
  order.status = statusSteps[0];
  order.createdAt = Date.now();

  const docRef = await db.collection('orders').add(order);
  res.json({ success: true, orderId: docRef.id });
});

// Simulate status update every 10 seconds
setInterval(async () => {
  const snapshot = await db.collection('orders').get();
  snapshot.forEach(async (doc) => {
    const data = doc.data();
    const currentIndex = statusSteps.indexOf(data.status);
    if (currentIndex < statusSteps.length - 1) {
      await doc.ref.update({ status: statusSteps[currentIndex + 1] });
    }
  });
}, 10000);

// Get order status
app.get('/order-status/:orderId', async (req, res) => {
  const doc = await db.collection('orders').doc(req.params.orderId).get();
  if (!doc.exists) return res.status(404).json({ error: 'Order not found' });
  res.json(doc.data());
});

app.listen(PORT, () => console.log(`✅ Server running at http://localhost:${PORT}`));
